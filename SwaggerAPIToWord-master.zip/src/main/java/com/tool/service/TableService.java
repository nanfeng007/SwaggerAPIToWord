package com.tool.service;

import com.tool.dto.Table;

import java.util.List;

/**
 * Created by zhangben on 2018/2/6.
 */
public interface TableService {
    List<Table> tableList();
    
    List<Table> tableList2();
}
